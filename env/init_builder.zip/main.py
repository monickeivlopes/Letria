import uvicorn
from iFastApi.utils import auto_builder
import api
from iFastApi import IFastAPI
from config import ServerConf

ifastapi = IFastAPI()
ifastapi.run(ServerConf)
if __name__ == '__main__':
    uvicorn.run(**ServerConf.SERVER_CONFIG)
