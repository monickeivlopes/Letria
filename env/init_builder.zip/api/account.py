import asyncio

from iFastApi import BaseRoute, DBManager
from iFastApi.api.RouteInfo import RouteInfo
from iFastApi.utils.iResponse import Success, JSONResponse

from db.account import Account as dbAccount
from model.account import LoginMode, RegisterMode, AccountDc


class Account(BaseRoute):
    def __init__(self, prefix=None):
        super().__init__(prefix)
        self.routers = [
            RouteInfo('/login', self.login),
            RouteInfo('/register', self.register, verify_auth=['ADMIN']),
            RouteInfo('/test_async_insert', self.async_insert)  # 异步
        ]
        self.db = dbAccount

    @staticmethod
    async def insert_data():
        asyncio.create_task(DBManager().async_execute('select * from test'))  # 创建一个任务 不等待 继续往下执行
        result = await DBManager().async_execute('select * from test')  # 等待执行完毕
        return result

    async def async_insert(self):
        asyncio.create_task(self.insert_data())
        return Success()

    def login(self, response: LoginMode) -> JSONResponse:
        account_dc = self.db.check_login(AccountDc(**response.dict()))
        return Success(data=account_dc)

    def register(self, response: RegisterMode) -> JSONResponse:
        account_dc = self.db.create_account(AccountDc(**response.dict()))
        return Success(data=account_dc.dict)
